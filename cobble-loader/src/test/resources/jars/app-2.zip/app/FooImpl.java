/*
 * Copyright 2015-2022 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0.
 * See the LICENSE.txt file for the full license.
 * https://www.apache.org/licenses/LICENSE-2.0
 */
package app;
import app.lib.Foo;

public class FooImpl implements Foo {
    @Override
    public String run(String... args) {
        return "FooA running...";
    }
}
